sap.ui.define([
   "search/PO/controller/BaseController"
], function (BaseController) {
   "use strict";
   return BaseController.extend("search.PO.controller.Invalid", {
      onInit: function () {
      }
   });
});